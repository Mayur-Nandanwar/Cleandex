import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container w-[552px] h-[1104px] bg-[rgba(0,0,0,0)] relative overflow-hidden mx-auto my-0'>
      <div className='h-[1104px] bg-[rgba(0,0,0,0)] absolute top-0 left-0 right-0'>
        <div className='w-[552px] h-[59px] bg-[rgba(0,0,0,0)] relative z-[32] mt-[26px] mr-0 mb-0 ml-0'>
          <div className='w-[58px] h-[58px] bg-[rgba(0,0,0,0)] absolute bottom-px right-[26px] z-[33]'>
            <div className='w-[51px] h-[52px] bg-[url(../assets/images/db280006c9e79d2adf5918802aa696d951f9c1b2.png)] bg-cover bg-no-repeat rounded-[25.75px] relative z-[34] mt-[4px] mr-0 mb-0 ml-[3px]' />
          </div>
          <span className="flex h-[34px] justify-start items-center font-['Inter'] text-[31.600000381469727px] font-semibold leading-[34px] text-[#dadddd] absolute bottom-[12px] right-[355px] text-left whitespace-nowrap z-[35]">
            CLEANDEX
          </span>
        </div>
        <div className='w-[527px] h-[65px] bg-[rgba(0,0,0,0)] relative z-[22] mt-[26px] mr-0 mb-0 ml-[17px]'>
          <div className='w-[208px] h-[64px] bg-[rgba(0,0,0,0)] absolute bottom-px right-[161px] z-[26]'>
            <button className='w-[204px] h-[59px] bg-[#76ce9e] rounded-[26px] border-solid border border-[#4d8c69] relative z-[27] pointer mt-[3px] mr-0 mb-0 ml-[3px]'>
              <span className="flex h-[23px] justify-start items-center font-['Inter'] text-[18.799999237060547px] font-semibold leading-[22.752px] text-[#def2e7] absolute bottom-[18px] right-[34px] text-left whitespace-nowrap z-[28]">
                Clean It Faster
              </span>
            </button>
          </div>
          <button className='w-[156px] h-[63px] bg-[rgba(0,0,0,0)] border-none absolute bottom-px right-0 z-[23] pointer'>
            <div className='w-[152px] h-[57px] bg-[#76ce9e] rounded-[28px] border-solid border border-[#569777] relative z-[24] mt-[4px] mr-0 mb-0 ml-[3px]'>
              <span className="flex h-[22px] justify-start items-center font-['Inter'] text-[18.399999618530273px] font-semibold leading-[22px] text-[#ddf2e7] absolute bottom-[20px] right-[34px] text-left whitespace-nowrap z-[25]">
                About Us
              </span>
            </div>
          </button>
          <div className='w-[156px] h-[63px] bg-[rgba(0,0,0,0)] absolute bottom-0 right-[371px] z-[29]'>
            <div className='w-[151px] h-[61px] bg-[url(../assets/images/76da3edb9f179a410d16f6c12d9dfbca74066052.png)] bg-cover bg-no-repeat relative z-30 mt-0 mr-0 mb-0 ml-[4px]'>
              <button className="w-[63px] h-[20px] font-['Inter'] text-[18px] font-semibold leading-[20px] text-[#ced0cf] border-none absolute bottom-[21px] right-[45px] whitespace-nowrap z-[31] pointer" />
            </div>
          </div>
        </div>
        <div className='w-[525px] h-[16px] bg-[url(../assets/images/d96776a32e9e2b2e87f118a7e2308e270ad33fab.png)] bg-cover bg-no-repeat relative z-[21] mt-[13px] mr-0 mb-0 ml-[12px]' />
        <div className='w-[552px] h-[900px] bg-[rgba(0,0,0,0)] relative z-[2] mt-[-1px] mr-0 mb-0 ml-0'>
          <div className='w-[526px] h-[49px] bg-[rgba(0,0,0,0)] relative z-[17] mt-0 mr-0 mb-0 ml-[12px]'>
            <div className='w-[510px] h-[47px] bg-[#182b2a] rounded-tl-[10px] rounded-tr-[26px] rounded-br-[10px] rounded-bl-[10px] relative overflow-hidden z-[18] mt-0 mr-0 mb-0 ml-[13px]'>
              <span className="flex h-[18px] justify-start items-center font-['Inter'] text-[13.899999618530273px] font-semibold leading-[16.822px] text-[#959f9d] absolute bottom-[11px] right-[349px] text-left whitespace-nowrap z-[19]">
                Kanpur Ganga River
              </span>
              <div className='w-[13px] h-[20px] bg-[url(../assets/images/76028244cb123779071ce4cff09e6ea15d9f9f8a.png)] bg-cover bg-no-repeat absolute bottom-[9px] right-[490px] z-20' />
            </div>
          </div>
          <div className='w-[537px] h-[307px] bg-[url(../assets/images/6ad493551262cf4543c47a38de22dab7113d2aec.png)] bg-cover bg-no-repeat relative z-[12] mt-[-2px] mr-0 mb-0 ml-[8px]'>
            <div className='w-[337px] h-[65px] bg-[rgba(0,0,0,0)] relative z-[13] mt-[241px] mr-0 mb-0 ml-[200px]'>
              <div className='w-[335px] h-[60px] bg-[url(../assets/images/ad18896c95b8516c678109c3d02016bb3c4fc324.png)] bg-cover bg-no-repeat relative z-[14] mt-[4px] mr-0 mb-0 ml-0'>
                <button className="w-[242px] h-[26px] font-['Inter'] text-[20.799999237060547px] font-semibold leading-[25.173px] text-[#f0faf4] border-none absolute bottom-[16px] right-[51px] whitespace-nowrap z-[16] pointer" />
                <div className='w-[19px] h-[4px] bg-[url(../assets/images/9eba9bdbfb57445d04a27c7908c7bd86258be63f.png)] bg-cover bg-no-repeat absolute bottom-[21px] right-[15px] z-[15]' />
              </div>
            </div>
          </div>
          <div className='w-[525px] h-[125px] relative z-[8] mt-[16px] mr-0 mb-0 ml-[17px]'>
            <div className='w-[522px] h-[113px] bg-[url(../assets/images/8c3a6ad10267310ca6540bbd7e6ce1bb008ec5ba.png)] bg-cover bg-no-repeat absolute bottom-[12px] right-[3px] z-[8]'>
              <span className="flex w-[374px] h-[78px] justify-start items-center font-['Inter'] text-[14.300000190734863px] font-semibold leading-[17.306px] text-[#c0c8c6] absolute bottom-[14px] right-[9px] text-left overflow-hidden z-[9]">
                Water pollution in Kanpur is a critical issue, especially
                <br />
                in the Ganges River, which is heavily contaminated by
                <br />
                industrial waste, untreated sewage, and chemical
                <br />
                runoff.
              </span>
              <div className='w-[35px] h-[35px] bg-[url(../assets/images/982ba9aa5446bc7ee522160e0e985083bc4f0e0c.png)] bg-cover bg-no-repeat absolute bottom-[49px] right-[433px] z-[11]' />
              <span className="flex h-[16px] justify-start items-center font-['Inter'] text-[13.199999809265137px] font-semibold leading-[15.975px] text-[#8a9896] absolute bottom-[26px] right-[424px] text-left whitespace-nowrap z-10">
                Clean it
              </span>
            </div>
            <div className='w-[523px] h-[125px] bg-[rgba(0,0,0,0)] absolute bottom-0 right-0 z-[7]' />
          </div>
          <div className='w-[525px] h-[16px] bg-[url(../assets/images/d728fa32fa3526e6cb63933ab73ac639af013630.png)] bg-cover bg-no-repeat relative z-[6] mt-[-4px] mr-0 mb-0 ml-[14px]' />
          <div className='flex w-[89px] h-[21px] justify-between items-center relative z-[5] mt-[18px] mr-0 mb-0 ml-[32px]'>
            <div className='w-[13px] h-[20px] shrink-0 bg-[url(../assets/images/a4a444cb2331bbd270564be5f01fee0c47bfde90.png)] bg-cover bg-no-repeat relative z-[5]' />
            <span className="h-[17px] shrink-0 font-['Inter'] text-[13.199999809265137px] font-semibold leading-[17px] text-[#949e9d] relative text-left whitespace-nowrap z-[4]">
              Delhi NCR
            </span>
          </div>
        </div>
      </div>
      <div className='w-[552px] h-[1104px] bg-[url(../assets/images/23fc441650d6f26f00043fcf26fcf2809537904e.png)] bg-cover bg-no-repeat absolute bottom-0 right-0 z-[1]' />
      <div className='w-[552px] h-[367px] bg-[url(../assets/images/12be1408-dad7-4cbd-a262-a446ece8d4ae.png)] bg-cover bg-no-repeat absolute bottom-0 right-0 z-[3]' />
    </div>
  );
}
